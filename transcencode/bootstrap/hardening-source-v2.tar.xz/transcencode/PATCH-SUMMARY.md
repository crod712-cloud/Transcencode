# Upstream files modified by the patch

The patch copies new files under these source folders:

```text
win/CS/HandBrakeWPF/Model/Transcencode
win/CS/HandBrakeWPF/ViewModels/Interfaces/ITranscencode*
win/CS/HandBrakeWPF/ViewModels/Transcencode*
win/CS/HandBrakeWPF/Views/Transcencode
```

It edits these existing upstream files:

```text
win/CS/HandBrakeWPF/Views/MainView.xaml
win/CS/HandBrakeWPF/Views/ShellView.xaml
win/CS/HandBrakeWPF/Views/PictureSettingsView.xaml
win/CS/HandBrakeWPF/Views/VideoView.xaml
win/CS/HandBrakeWPF/ViewModels/MainViewModel.cs
win/CS/HandBrakeWPF/ViewModels/PictureSettingsViewModel.cs
win/CS/HandBrakeWPF/ViewModels/VideoViewModel.cs
win/CS/HandBrakeWPF/Services/Scan/Interfaces/IScan.cs
win/CS/HandBrakeWPF/Services/Scan/LibScan.cs
win/CS/HandBrakeWPF/Properties/Resources.resx
win/CS/HandBrakeWPF/HandBrakeWPF.csproj
win/CS/HandBrakeWPF/Utilities/GeneralUtilities.cs
win/CS/HandBrake.App.Core/Utilities/DirectoryUtilities.cs
win/CS/HandBrake.Worker/Watcher/InstanceWatcher.cs
win/CS/HandBrake.Worker/Program.cs
```

Each edit is anchored to expected upstream text. The patch aborts rather than guessing when upstream changes invalidate an anchor. Every modified upstream file is copied into a timestamped backup directory before the first edit.
