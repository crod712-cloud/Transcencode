# Transcencode

**Analyze. Encode. Verify.**

Transcencode is a Windows-focused fork of the HandBrake graphical application. It keeps HandBrake's existing Windows WPF workflow—Summary, Dimensions, Filters, Video, Audio, Subtitles, Chapters, presets, preview, queueing, and native encoders—and adds clearer analysis and verification tools directly to that interface.

This repository work is **not** the retired PowerShell/HandBrakeCLI wrapper. The application being built is HandBrake's real Windows WPF GUI and native engine with Transcencode features integrated into it.

## Native tabs in the hardening alpha

- **Analyze** performs a separate multi-sample picture scan. It measures content brightness, shadows, contrast, edge detail, sampled scene variation, and encoding difficulty. Uniform black letterbox or pillarbox areas are measured separately so they do not make the movie appear artificially dark. The recommendation is applied to HandBrake's real Video task only when the selected encoder supports adjustable Constant Quality.
- **Source Tracks** makes all source audio and subtitle tracks immediately visible, including language, codec/description, channels, bitrate, sample rate, names, subtitle type, and capabilities. It also explains HDR and Dolby Vision findings without claiming that metadata will survive an incompatible pipeline.
- **Upscale & Enhance** applies target dimensions to HandBrake's real Dimensions task. It handles landscape and portrait sources, accounts for the current crop when deciding whether upscaling is required, and warns before aspect-ratio distortion. The stable path uses HandBrake's standard scaler. NVIDIA RTX AI Super Resolution is not falsely simulated or claimed as complete.
- **Verify** reopens a completed output with the packaged HandBrakeCLI and compares structural properties against the configured job: readability, selected job-range duration, resolution bounds, audio tracks, subtitle streams, bit depth, and requested dynamic HDR metadata.
- **Live Engine** follows HandBrake's native log and queue services and shows actual engine output, progress, elapsed time, ETA remaining, estimated finish time, average frame rate, and the active log file. ETA counts down between native HandBrake updates.
- **Transcencode Settings** controls whole-interface scaling, Deep Analyze sample coverage, and automatic opening of Live Engine when encoding begins.

## NVENC, quality, and Dolby Vision

NVIDIA NVENC remains a normal first-class HandBrake encoder. Transcencode does not silently substitute software x265. The native Video tab explains that Constant Quality varies bitrate by scene, that lower values generally mean higher quality and larger files, and that no single CQ value guarantees a visually lossless result.

When Dolby Vision is detected, Transcencode reports it and treats preservation as conditional on the selected encoder, codec profile, container, source profile, and dynamic-metadata passthrough setting. Verify inspects the completed output rather than silently claiming preservation or automatically changing the encoder.

## What the automated gates currently test

The fast Windows gate now performs all of the following before publishing an artifact:

1. Static source, XAML, patch-anchor, workflow, and wording validation.
2. Compiles the real Windows WPF GUI and HandBrake worker with .NET 10.
3. Runs regression tests for black-bar exclusion, dark-scene handling, dimensions, portrait presets, job-range duration, and mixed-output JSON parsing.
4. Launches `Transcencode.exe` on a Windows runner and checks that it remains alive.
5. Confirms Transcencode creates `%APPDATA%\Transcencode` and does not write into `%APPDATA%\HandBrake` during startup.
6. Generates a small video, scans it with the packaged HandBrakeCLI, encodes it, and rescans the result.

The full native gate separately compiles `hb.dll` and HandBrakeCLI from the same repository commit with NVIDIA NVENC and NVDEC enabled, then repeats the Windows tests against those matching binaries.

## Honest limits

Deep Analyze currently studies representative still pictures rather than decoding every frame. It does not yet measure full temporal motion, perform source/output VMAF or SSIM comparisons, or prove that an encode is visually lossless. Verify is structural, not yet frame-by-frame visual or measured audio-sync verification. RTX Video SDK integration is planned but not present. A passing build is a development gate, not a declaration that the application is finished.

Those limitations are shown in the interface instead of being hidden behind misleading labels.

## Development branch

Native development is performed on:

```text
transcencode/native-wpf-alpha
```

The `master` branch remains aligned with upstream HandBrake while the native implementation is hardened.

## Build

GitHub Actions compiles the Windows GUI, runs algorithm and runtime smoke tests, and also builds the native engine with NVIDIA NVENC/NVDEC support. See [BUILDING.md](BUILDING.md) and [STATUS.md](STATUS.md).

## License

The combined work remains licensed under GNU GPL version 2, consistent with HandBrake. See the upstream `LICENSE` file and [LICENSE-NOTICE.md](LICENSE-NOTICE.md).
