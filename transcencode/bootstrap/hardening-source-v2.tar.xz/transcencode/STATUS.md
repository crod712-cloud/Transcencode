# Native WPF hardening status

## Implemented in source

- Native HandBrake WPF tab integration for Analyze, Source Tracks, Upscale & Enhance, Verify, Live Engine, and Transcencode Settings.
- Dedicated high-sample preview scan API for Deep Analyze that does not masquerade as HandBrake's normal source-details scan.
- Picture metrics for content brightness, shadow load, contrast, edge detail, histogram variation, sampled difficulty, and black-border area.
- Black letterbox/pillarbox exclusion so borders do not inflate dark-scene scoring, with a regression test preventing uniformly dark scenes from being mistaken for bars.
- Cancellable Deep Analyze with stale-run protection when the source changes.
- Encoder-aware Constant Quality recommendations that update HandBrake's actual Video controls and refuse unsupported/lossless encoders.
- Plain-language Constant Quality and NVENC guidance on the native Video tab.
- Source audio/subtitle tables and conditional HDR/Dolby Vision summary.
- HandBrake Dimensions integration for same-source, 1080p, 1440p, 4K, and custom targets, including portrait sources and crop-aware upscale decisions.
- Structural output verification through packaged HandBrakeCLI with cancellation, timeout, robust JSON isolation, current job-range duration comparison, bit-depth checks, and requested dynamic HDR checks.
- Native log, progress, elapsed, smooth ETA countdown, estimated finish, speed, active-log name, and bounded log display.
- Whole-interface scaling from 100% through 200%.
- Clear crop labels and explanations, including `Same as source (preserve original black bars)`.
- Separate `%APPDATA%\Transcencode` settings/log storage.
- Native executable name `Transcencode.exe`, with worker process checks updated accordingly.
- Visible source files in the repository; the temporary hidden bootstrap archive is removed by the hardening commit.
- Windows regression and runtime smoke-test scripts.
- Fast Windows compile gate using verified official HandBrake runtime binaries.
- Full native-engine gate compiling NVENC/NVDEC-enabled `hb.dll` and HandBrakeCLI from the same commit.

## Automated gates

1. Static integration validation passes with XAML parsing, C# and PowerShell delimiter checks, interface/implementation checks, patch-anchor requirements, workflow checks, and overclaiming checks.
2. Algorithm tests cover dimension normalization, portrait orientation, chapter/seconds/frame duration ranges, JSON extraction, letterbox exclusion, and dark-scene handling.
3. Windows GUI startup smoke test requires `Transcencode.exe` to remain alive and use isolated AppData.
4. Generated-media smoke test requires packaged HandBrakeCLI to scan, encode, and rescan a real file.
5. Full native gate must compile the engine with `--enable-nvenc` and `--enable-nvdec` before packaging.

## Required hardware/manual gates

- Load real SDR, HDR10, HDR10+, and Dolby Vision sources on the user's Windows workstation.
- Confirm all six tabs receive the correct current HandBrake title and job after switching titles and presets.
- Run Deep Analyze at 24, 48, and 72 samples, cancel it mid-scan, switch sources during cancellation, and confirm the normal source overlay never remains stuck.
- Confirm a real RTX 3090 or RTX 2080 Ti job stays on the selected NVENC encoder in the actual engine log.
- Confirm Live Engine attaches to the active encode log and ETA/finish time remain sensible during a complete encode.
- Verify audio/subtitle selection, crop modes, HDR metadata, and partial-range encodes against completed outputs.
- Stress-test large logs, queue errors, stopped queues, invalid output files, and a hung HandBrakeCLI verification process.

## Not complete yet

- VMAF/SSIM source-output test-encode scoring.
- Automatic search for the objectively lowest acceptable CQ.
- Full temporal motion analysis across every frame.
- RTX Video SDK AI upscaling.
- Frame-by-frame visual verification and measured audio-sync analysis.
- Fully rebranded NSIS installer. Portable builds remain development artifacts until runtime testing is complete.
